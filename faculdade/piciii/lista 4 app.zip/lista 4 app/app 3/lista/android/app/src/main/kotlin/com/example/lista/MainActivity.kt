package com.example.lista

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
