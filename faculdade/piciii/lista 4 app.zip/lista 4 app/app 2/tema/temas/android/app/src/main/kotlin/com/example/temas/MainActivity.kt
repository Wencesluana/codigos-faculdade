package com.example.temas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
