package com.example.contador

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
