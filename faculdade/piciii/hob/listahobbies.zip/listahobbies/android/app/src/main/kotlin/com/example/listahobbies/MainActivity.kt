package com.example.listahobbies

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
